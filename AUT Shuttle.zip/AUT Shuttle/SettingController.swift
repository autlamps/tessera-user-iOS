//
//  SettingController.swift
//  AUT Shuttle
//
//  Created by The Ton Le on 18/08/18.
//  Copyright © 2018 The Ton Le. All rights reserved.
//

import UIKit
import Foundation

class SettingController: UIViewController {
    
    //MARK: - Log Out Button
    /*******************************************************************/
    
    @IBAction func logOutButton(_ sender: Any) {
        logOut()
    }
    
    //MARK: - Log Out function
    /*******************************************************************/
    func logOut() {
        UserDefaults.standard.removeToken()
        UserDefaults.standard.removeQRCode()
        UserDefaults.standard.removeValue()
        UserDefaults.standard.setLoggedIn(val: false)
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "loginScreen")
        self.showDetailViewController(vc, sender: (Any).self)
    }
}
