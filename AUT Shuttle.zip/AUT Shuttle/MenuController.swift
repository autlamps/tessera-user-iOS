//
//  MenuController.swift
//  AUT Shuttle
//
//  Created by The Ton Le on 15/08/18.
//  Copyright © 2018 The Ton Le. All rights reserved.
//

import Foundation
import UIKit

class MenuController: UIViewController {
    @IBOutlet weak var imageQR: UIImageView!
    @IBOutlet weak var balanceValue: UILabel!
    
    override func viewDidLoad() {
        generateQRCode(from: UserDefaults.standard.getQRCode())
        balanceValue.text = "$\(UserDefaults.standard.getValue())"
    }
    
    //MARK: - QR Code generator
    /*******************************************************************/
    
    func generateQRCode(from string: String) {
        let data = string.data(using: String.Encoding.ascii)
    
        if let filter = CIFilter(name: "CIQRCodeGenerator") {
            filter.setValue(data, forKey: "inputMessage")
            let transform = CGAffineTransform(scaleX: 3, y: 3)
    
            if let output = filter.outputImage?.transformed(by: transform) {
                imageQR.image = UIImage(ciImage: output)
            }
        }
    }
    
    
}
