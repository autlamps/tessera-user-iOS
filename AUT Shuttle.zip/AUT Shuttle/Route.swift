//
//  Route.swift
//  AUT Shuttle
//
//  Created by The Ton Le on 24/08/18.
//  Copyright © 2018 The Ton Le. All rights reserved.
//

import Foundation

struct Routes {
    static var routesArr: [String] = []
}

struct Routes2 {
    static var routesArr: [Route] = []
}

class Route: Decodable {

    var name: String = ""
    var description: String = ""
    var cost: Int = 0

    init() {
        
    }
    
    convenience init(n: String, des: String, c: Int) {
        self.init()
        name = n
        description = des
        cost = c
    }
}
