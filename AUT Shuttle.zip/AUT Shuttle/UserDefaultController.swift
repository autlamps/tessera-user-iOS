//
//  UserDefaultController.swift
//  AUT Shuttle
//
//  Created by The Ton Le on 28/08/18.
//  Copyright © 2018 The Ton Le. All rights reserved.
//

import Foundation

extension UserDefaults {
    
    //MARK: - Token
    /*******************************************************************/
    
    func setToken(token: String) {
        set(token, forKey: "userToken")
        synchronize()
    }
    
    func getToken() -> String {
        return string(forKey: "userToken")!
    }
    
    func removeToken() {
        removeObject(forKey: "userToken")
        synchronize()
    }
    
    //MARK: - User Value
    /*******************************************************************/
    
    func setValue(val: Int) {
        set(val, forKey: "userCurrentValue")
        synchronize()
    }
    
    func getValue() -> Int {
        return integer(forKey: "userCurrentValue")
    }
    
    func removeValue() {
        removeObject(forKey: "userCurrentValue")
        synchronize()
    }
    
    //MARK: - is Logged in
    /*******************************************************************/
    
    func setLoggedIn(val: Bool) {
        set(val, forKey: "setLoggedIn")
        synchronize()
    }
    
    func isLoggedIn() -> Bool {
        return bool(forKey: "setLoggedIn")
    }
    
    //MARK: - QR Code
    /*******************************************************************/
    
    func setQRCode(qrcode: String) {
        set(qrcode, forKey: "userQR")
        synchronize()
    }
    
    func getQRCode() -> String {
        return string(forKey: "userQR")!
    }
    
    func removeQRCode() {
        removeObject(forKey: "userQR")
        synchronize()
    }
    
    //MARK: - Date Time Expire
    /*******************************************************************/
    
    func setDateTimeExpire(datetime: String) {
        set(datetime, forKey: "dateTimeExpire")
        synchronize()
    }
    
    func getDateTimeExpire() -> String {
        return string(forKey: "dateTimeExpire")!
    }
    
    func removeDateTimeExpire() {
        removeObject(forKey: "dateTimeExpire")
        synchronize()
    }
    
    //MARK: - is Connected to internet
    /*******************************************************************/
    
    func setIsConnectedNetwork(isConnected: Bool) {
        set(isConnected, forKey: "isConnected")
        synchronize()
    }
    
    func getIsConnectedNetwork() -> Bool {
        return bool(forKey: "isConnected")
    }
    
    func removeIsConnected() {
        removeObject(forKey: "isConnected")
        synchronize()
    }
}
