//
//  Token.swift
//  AUT Shuttle
//
//  Created by The Ton Le on 15/08/18.
//  Copyright © 2018 The Ton Le. All rights reserved.
//

import Foundation

class Token {
    var token: String = ""
    
    init() {
    }
    convenience init(tok: String) {
        self.init()
        token = tok
    }
}
